using UnityEngine;

public class Unit : MonoBehaviour { // 체력을 가지는 객체가 상속
    public float health;
    public float maxHealth;

}