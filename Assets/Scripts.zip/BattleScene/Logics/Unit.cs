using UnityEngine;

public class Unit : MonoBehaviour {
    public float health;
    public float maxHealth;

}