using System.Collections.Generic;
using UnityEngine;

public interface IUpgradable {
    void Upgrade();
}