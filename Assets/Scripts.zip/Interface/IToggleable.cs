using UnityEngine;

public interface IToggleable {
    public void Toggle();
}