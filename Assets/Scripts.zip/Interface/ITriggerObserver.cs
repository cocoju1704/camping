public interface ITriggerObserver
{
    void OnTriggerEntered(string objName);
    void OnTriggerExited(string objName);
}