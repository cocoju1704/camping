using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class LevelUpMaterials {
    public List<Vector2Int> materials;
}